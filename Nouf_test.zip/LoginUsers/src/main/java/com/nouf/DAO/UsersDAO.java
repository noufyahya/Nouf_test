package com.nouf.DAO;

import java.util.List;

import com.nouf.DTO.LoginUserDTO;
import com.nouf.exceptions.UserIdNotFoundException;


public interface UsersDAO {

	public int addUser(LoginUserDTO dto);
	public LoginUserDTO getUser(int userId) throws UserIdNotFoundException;
	public List<LoginUserDTO> getAllUsers();
}
