package com.nouf.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nouf.DTO.LoginUserDTO;
import com.nouf.dbUtils.*;
import com.nouf.exceptions.UserIdNotFoundException;

public class UsersDAOImpl implements UsersDAO{

	private static Connection connection;

	static {
		new DBConnection();
		try {
			connection = DBConnection.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// may or may not need the numbers
	// COULD be VOID
	public int addUser(LoginUserDTO dto) {

		String sql = "insert into ctsdubai.login_users values(?,?)";
		int rowsAdded = 0;
		int userId = dto.getUserId();
		String userName = dto.getUserName();

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			preparedStatement.setString(2, userName);

			rowsAdded = preparedStatement.executeUpdate();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return rowsAdded;

	}

	public LoginUserDTO getUser(int userId) throws UserIdNotFoundException {
		String sql = "SELECT * FROM ctsdubai.login_users WHERE userid = ?";
		LoginUserDTO user = null;

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				user = new LoginUserDTO(rs.getInt(1), rs.getString(2));
			} else
				throw new UserIdNotFoundException("user not found!! ");
		} catch (SQLException e) {
			System.out.println(e.getMessage());

		}
		return user;
	}

	public List<LoginUserDTO> getAllUsers() {

		List<LoginUserDTO> users = new ArrayList<>();
		String sql = "select * from ctsdubai.login_users";

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				users.add(new LoginUserDTO(rs.getInt(1), rs.getString(2)));
			}
		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}
		return users;
	}

}
