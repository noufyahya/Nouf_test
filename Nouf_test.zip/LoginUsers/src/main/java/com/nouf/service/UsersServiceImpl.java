package com.nouf.service;

import java.util.List;

import com.nouf.DAO.UsersDAO;
import com.nouf.DAO.UsersDAOImpl;
import com.nouf.DTO.LoginUserDTO;
import com.nouf.exceptions.UserIdNotFoundException;

public class UsersServiceImpl implements UsersServices {

	private UsersDAO dao = new UsersDAOImpl();

	// private UsersD
	public String addUser(LoginUserDTO dto) {
		dto.setUserName(dto.getUserName().toUpperCase());
		int usersAdded = dao.addUser(dto);
		if (usersAdded == 0) {
			return "faild to add you user";
		} else
			return "User Added";
	}

	public String getUser(int userId) {
		try {
			LoginUserDTO user=dao.getUser(userId);
			return user.toString();
		}catch(UserIdNotFoundException e) {
			return e.getMessage();
		}
	}

	public List<LoginUserDTO> getAllUsers() {
		return dao.getAllUsers();
	}

}
