package com.nouf.service;

import java.util.List;
import com.nouf.DTO.LoginUserDTO;

public interface UsersServices {

	public String addUser(LoginUserDTO dto);
	public String getUser(int userId);
	public List<LoginUserDTO> getAllUsers();

}
