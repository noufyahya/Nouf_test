package com.nouf.dbUtils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//table name:: login_users
public class DBConnection {

	private static Connection connection;

	static {
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ctsdubai", "root", "root");
            System.out.println("Connection made!");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		return connection;
	}
}
