package com.nouf.options;

import java.util.List;
import java.util.Scanner;

import com.nouf.DTO.LoginUserDTO;
import com.nouf.service.UsersServiceImpl;
import com.nouf.service.UsersServices;

public class ChooseOptions {
	private UsersServices us = new UsersServiceImpl();
	private static Scanner sc;

	static {
		sc = new Scanner(System.in);
	}

	public ChooseOptions() {
		choose();
	}

	private void choose() {
		int x = -7;
		System.out.println("=======Main Menu=======");
		System.out.println("1- Add 1 user");
		System.out.println("2- Get a user by Id");
		System.out.println("3- Get All Users");
		System.out.println("4- Exit!!");
		if (sc.hasNext()) {
			x = sc.nextInt();
			doOptions(x);
		} else {
			System.out.println("Enter a no from 1 till 4");
			sc.next();
			choose();
		}
	}

	private void doOptions(int x) {
		switch (x) {
		case 1:
			addaUser();
			choose();
			break;
		case 2:
			getaUser();
			choose();
			break;
		case 3:
			getAllUsers();
			choose();
			break;
		case 4:
			System.out.println("End");
			break;
		default:
			System.out.println("Wrong insert");
		}
	}

	private void getAllUsers() {

		List<LoginUserDTO> users=us.getAllUsers();
		users.stream().forEach(System.out::println);
	}

	private void getaUser() {
	
		System.out.println("Start Getting a User : ");
		
		System.out.println("Enter Id : ");
		int id;
		if(sc.hasNextInt()) {
			id=sc.nextInt();
		}else {
			System.out.println("ERORR::: Please provide an Integer");
			sc.next();
			return;
		}
		
		String result = us.getUser(id);
		System.out.println(result);
		System.out.println("End Getting a User : ");

	}

	private void addaUser() {
		int Id;
		System.out.println("Start Adding");
		System.out.println("Enter Id");
		if(sc.hasNextInt()) {
			Id=sc.nextInt();
		}else {
			System.out.println("ERROR:: Must be an Integer");
			sc.next();
			return;
		}
		System.out.println("Enter a Name:: ");
		String userName=sc.next();
		String rs=us.addUser(new LoginUserDTO(Id,userName));
		System.out.println(rs);
		System.out.println("End Adding");

		
	}
}
