package com.nouf.main;

import com.nouf.options.ChooseOptions;

public class MainApp {
	public static void main(String[] args) {
		new ChooseOptions();
	}
}
